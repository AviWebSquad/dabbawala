<?php
include 'include/header.php';
?>
<div class="content-wrapper">
  
  <!-- Main content -->
  <section class="content">

  </section>
</div>
<?php
include 'include/footer.php';
?>
