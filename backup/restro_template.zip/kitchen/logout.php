<?php
session_start();
$_SESSION['newKitchenLogin']='';
header('location:index.php');
?>