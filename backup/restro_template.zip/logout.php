<?php
session_start();
$_SESSION['newBuyerLogin']='';
header('location:index.php');
?>